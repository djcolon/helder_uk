import boto3
import logging
import json

from datetime import datetime

from pytz import timezone

from botocore.exceptions import ClientError

# Script level config
dry_run = False
verbose_logging = False

# These maintenance windows will get applied to all scheduled machines.
maintenance_windows = [
    {
        # monday is 0, and this increments throughout the week (e.g. friday = 4)
        "days": "2",
        "start": "04:55",
        "stop": "08:00"
    }
]

# Setup simple logging for INFO
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Get all the instances.
def get_instances():
    '''
    Returns all istances with a schedule tag set to 'true'
    '''
    # Define the connection
    ec2 = boto3.resource('ec2')
    # Use the filter() method of the instances collection to retrieve
    # all running EC2 instances with a tag called 'schedule' set to 'true'.
    filters = [
        {
            'Name': 'tag:schedule',
            'Values': ['true']
        }
    ]
    return ec2.instances.filter(Filters=filters)

def start_stop_instance(instance, start: bool):
    '''
    Starts or stops a provided instance.
    Start = True to start machine.
    Respects dry_run flag.
    '''
    # Start/stop and emit a log entry.
    try:
        if start:
            logger.info(f"Starting instance {instance.instance_id} self-serve")
            instance.start(DryRun = dry_run)
        else:
            logger.info(f"Stopping instance {instance.instance_id} self-serve")
            instance.stop(DryRun = dry_run)
    except ClientError as e:
        # A success with dryrun set will throw an error.
        # Catch and ignore these.
        if 'Request would have succeeded, but DryRun flag is set' not in str(e):
            raise
        else:
            logger.info("DryRun is enabled, start/stop was simulated.")

def set_tag(instance, key, value):
    '''
    Set tag and emit a log entry.
    '''
    try:
        # Also set self_serve tag to stop
        logger.info(f"Setting self-serve tag to stop for {instance.instance_id}")
        tag = instance.create_tags(
            DryRun = dry_run,
            Tags = [
                {
                    'Key': key,
                    'Value': value
                },
            ]
        )
    except ClientError as e:
        # A success with dryrun set will throw an error.
        # Catch and ignore these.
        if 'Request would have succeeded, but DryRun flag is set' not in str(e):
            raise
        else:
            logger.info("DryRun is enabled, setting tag was simulated.")

def parse_time(time_string):
    '''
    Parses a HH:MM tag to a datetime.
    Will throw on failure to parse.
    '''
    return datetime.strptime(time_string, '%H:%M')

def parse_days(tag_value, tag_key = 'days', instance_id = 'unknown'):
    '''
    Parses a days string into an array of days.
    Will return an empty array on failure.
    tag_key and instance_id are only used for logging.
    '''
    try:
        days = list(
            map(
                int,
                tag_value.split(',')
            )
        )
    except:
        if verbose_logging:
            logger.warning(f"Failed parsing {tag_key} tag '{tag_value}' for instance {instance_id}. Days set to [].")
        # If the days tag is invalid set days to empty but continue.
        days = []
    return days

def parse_maintenance_windows_json_string(maintenance_windows_string, instance_id = 'unknown'):
    '''
    Parses a maintenance_window tag's JSON into an array of windows.
    '''
    try:
        result = json.loads(maintenance_windows_string)
    except:
        logger.warning(f"Failed parsing maintenance window tag: '{maintenance_windows_string}' for instance {instance_id}. Window ignored.")
        return []
    # Test it is an array.
    if type(result) is not list:
        logger.warning(f"Maintenance window tag: '{maintenance_windows_string}' for instance {instance_id} was not a list. Window ignored.")
        return []
    # Then finally test every item contains the required definitions.
    for window in result:
        if 'start' not in window or 'stop' not in window:
            logger.warning(f"Maintenance window tag: '{maintenance_windows_string}' for instance {instance_id} had missing start/stop entries. Window ignored.")
            return []
    return result

def process_tags(tags, instance_id = 'unknown'):
    '''
    Processes tags on an instance into usable variables.
    '''
    start = None
    stop = None
    days = []
    self_serve = ''
    instance_maintenance_windows = []
    for tag in tags:
        if tag['Key'] == 'start':
            try:
                start = parse_time(tag['Value'])
            except:
                raise Exception(f"Failed parsing start tag '{tag['Value']}' for instance {instance_id}.")
        if tag['Key'] == 'stop':
            try:
                stop = parse_time(tag['Value'])
            except:
                raise Exception(f"Failed parsing stop tag '{tag['Value']}' for instance {instance_id}.")
        if tag['Key'] == 'days':
            days = parse_days(tag['Value'], tag['Key'], instance_id)
        if tag['Key'] == 'self-serve-schedule':
          self_serve = tag['Value']
          if self_serve != 'start' and self_serve != 'stop':
            logger.error(f"Failed parsing self-serve-schedule tag '{tag['Value']}' for instance {instance_id}.")
            self_serve = ''
        if tag['Key'] == 'maintenance_windows':
            instance_maintenance_windows = parse_maintenance_windows_json_string(tag['Value'])
    # Check we received all required tags.
    if start is None or stop is None:
        raise Exception(f"Did not receive all required tags for instance {instance_id}.")
    # Check tags make sense.
    if start >= stop:
        raise Exception(f"Start time is after stop time for instance {instance_id}.")
    # Finally return them as a tuple.
    return (start, stop, days, self_serve, instance_maintenance_windows)

def determine_on_today(days, now):
    '''
    Determines whether now as a day is present in the days array.
    '''
    # Default to being on if no days are given.
    if len(days) == 0:
        return True
    today = now.weekday()
    for day in days:
        if day == today:
            return True
    return False

def determine_in_maintenance_windows(now, maintenance_windows):
    '''
    Tests whether the instance should be on because it is in one of the
    maintenance windows.
    '''
    in_window = False
    for maintenance_window in maintenance_windows:
        days = []
        if 'days' in maintenance_window:
            days = parse_days(maintenance_window["days"])
        on_today = determine_on_today(days, now)
        start = parse_time(maintenance_window["start"])
        stop = parse_time(maintenance_window["stop"])
        in_window = (
            on_today 
            and start.time() <= now.time()
            and stop.time() >= now.time()
        )
        # If we are in_window, break out and return.
        if in_window:
            break
    if in_window:
        logger.info("Machine in window due to maintenance.")
    return in_window

def determine_in_window(start, stop, on_today, now):
    '''
    Uses start, stop, on_today and now to determine whether the machine should
    be on (according to the time-window) today.
    '''
    in_window = (
        on_today
        and start.time() <= now.time()
        and stop.time() >= now.time()
    )
    if in_window:
        logger.info("Machine in window due to tags.")
    return in_window

def determine_action(instance_running, self_serve, in_window):
    '''
    Determines what action to take for the machine for the given parameters.
    Returns action as a tuple of bools:
    (start_instance, remove_start_tag)
    - start_instance is True for start, False for Stop and None for ignore.
    - remove_start_tag is True to set 'self-serve-schedule' to 'stop'
      false to leave as-is.
    '''
    start_instance = None
    remove_start_tag = False

    # Handle things differently between self-serve mode and normal mode.
    if verbose_logging:
        logger.info(f'Determining action: self serve: "{self_serve}", instance_running: "{instance_running}", in_window: "{in_window}".')
    if self_serve == '':
        # Normal mode.
        if instance_running and not in_window:
            start_instance = False
        if not instance_running and in_window:
            start_instance = True
    elif self_serve == 'start':
        if instance_running and not in_window:
            start_instance = False
            remove_start_tag = True
        elif not instance_running and in_window:
            start_instance = True
    elif self_serve == 'stop' and instance_running:
        start_instance = False
    if verbose_logging:
        logger.info(f'Determined action: start_instance: "{start_instance}", remove_start_tag: "{remove_start_tag}".')
    return (start_instance, remove_start_tag)

def process_instance(instance, now):
    '''
    Process an instance
    '''
    logger.info('Processing ' + instance.instance_id)
    # First check if the instance is in a state we want to process.
    if not (
        instance.state['Name'] == 'running'
        or instance.state['Name'] == 'stopped'
    ):
        logger.warning(f"Ignoring instance {instance.instance_id} in state: {instance.state['Name']}.")
        return
    instance_running = instance.state['Name'] == 'running'

    # process the instance's tags.
    start = None
    stop = None
    days = []
    self_serve = ''
    instance_maintenance_windows = []

    # Get the tags
    (
        start,
        stop,
        days,
        self_serve,
        instance_maintenance_windows
    ) = process_tags(instance.tags, instance.instance_id)

    on_today = determine_on_today(days, now)
    
    # Determine our required state.
    in_schedule_window = determine_in_window(
        start,
        stop,
        on_today,
        now
    )
    in_maintenance_window = determine_in_maintenance_windows(
        now,
        maintenance_windows + instance_maintenance_windows
    )
    in_window = in_schedule_window or in_maintenance_window

    # If we're in maintenance window, clear the self_serve tag to ensure it is
    # treated as a non self-serve window.
    if in_maintenance_window:
        self_serve = ''

    # And then determine our actions.
    (start_instance, remove_start_tag) = determine_action(
        instance_running,
        self_serve,
        in_window
    )

    # Then carry them out.
    if start_instance is not None:
        start_stop_instance(instance, start_instance)
    if remove_start_tag:
        set_tag(instance, 'self-serve-schedule', 'stop')

def lambda_handler(event, context):
    # First determine the time in London UK.
    tz = timezone('Europe/London')
    now = datetime.now(tz)
    logger.info("Starting smartEc2Schedule at: " + str(now))
    # Get instances.
    instances = get_instances()
    for instance in instances:
        try:
            process_instance(instance, now)
        except Exception as exception:
            logger.error(f"Skipped instance {instance.instance_id} due to fatal error: {exception}")

    logger.info("Done.")
