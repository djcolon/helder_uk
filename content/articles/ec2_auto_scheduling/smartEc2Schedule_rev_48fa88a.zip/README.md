# SmartEC2Schedule

**Daniel Colon - 20/08/2022**

## Installation

This script is designed to run as a lambda function.
If you want to run the tests locally make sure boto3 and pytz are installed.

### Timeout

Standard Lambda timeout of 3 seconds may be too short for this function,
it is recommended to allow 30s for the function to run, although the size of
your fleet may require higher or lower settings. Some experimentation may be
required.

## Testing

Simply run `python3 -m pytest` in the root directory.

## Packaging for lambda

The script uses the pytz package to properly handle running in specific
timezones. This is not available in the standard lambda runtime and needs to be
packaged with the script. Simply run `./package_for_lambda.sh` from the project
root. This will generate a `smartEc2Schedule.zip` you can upload to lambda.

## To-do

- Pull maintenance windows and dry_run script level settings into environment
  variables.

## General functioning

This script is designed to run intermittently as a Lambda function. It is
suggested it is run once every minute.
It will get all EC2 instances with a tag with name 'schedule' and value
'true'.
It then looks at the 'start' and 'stop' tags (which should be of the format
HH:MM). It parses them into a time (in the UK/London timezone) and compares
them to the current time. If the current time is after start, and before stop,
it will ensure the machine is running. If the time is outside the start-stop
window it will stop the machine.
A list of weekdays the machine should be running on can optionally be
provided. This is meant to be sued solely by non-self-serve.
The tag should be name 'days' and contain a comma-separated list of weekday
numbers the machine should be running, where Monday is 0, and this increments
throughout the week (e.g. Friday = 4):
- 0 mon
- 1 tue
- 2 wed
- 3 thu
- 4 fri
- 5 sat
- 6 sun

example: to run the machine mon - fri you'd use:
days: 0,1,2,3,4

# Maintenance windows

Two methods of setting maintenance windows are supported.
The maintenance_windows list defined at the top of the script is applied to
every instance that is scheduled. The machine will turn on if it is inside any
of the maintenance windows.
Instance specific maintenance windows can be set by adding a tag with the key
'maintenance_windows' that contains a JSON array of one or more windows.
e.g:
`[{"days":"1,2","start":"05:00","stop":"08:00"},{"days":"3","start":"02:50","stop":"03:30"}]`
Note the 'days' are optional. If left out the window will apply to any day.

# Self-serve

The script also supports self-serve mode. This allows a user to request a
machine being powered up for a single stretch of time. When the stop time is
reached the machine will be shut down and not booted up again.
When a machine that has the schedule tag set to true also has a
'self-serve-schedule' tag, the machine is treated as being in self-serve mode.
If the self-serve tag is set to start, and the machine is powered down, and
the time is inside the window defined by the start-stop tags, the machine will
be powered on.
If the self-serve tag is set to start, and the machine is powered up, and the
time is outside the start-stop window, the machine will be powered down, and
the self-serve tag will be set to 'stop'.
If the self-serve tag is set to stop, and the machine is powered down, no
action will be taken regardless of the start-stop window.
Truth table for machine that is running:
```
┌────────────┬─────────────────────────────┬──────────────────┐
│ =Started=  │      self-serve: start      │ self-serve: stop │
├────────────┼─────────────────────────────┼──────────────────┤
│ in window  │ ignore                      │ power down       │
│ out window │ power down, set tag to stop │ power down       │
└────────────┴─────────────────────────────┴──────────────────┘
```
Truth table for machine that is stopped:
```
┌────────────┬─────────────────────────────┬──────────────────┐
│ =Stopped=  │ self-serve: start           │ self-serve: stop │
├────────────┼─────────────────────────────┼──────────────────┤
│ in window  │ power up                    │ ignore           │
│ out window │ ignore                      │ ignore           │
└────────────┴─────────────────────────────┴──────────────────┘
```

# Required IAM permissions

- ec2:DescribeInstance
- kms:CreateGrant (to start an ec2 instance with an encrypted volume)
- ec2:StartInstances
- ec2:StopInstances
- ec2:CreateTags
- logs:CreateLogStream
- logs:CreateLogGroup
- logs:PutLogEvents

An example policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "logs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogStream",
        "logs:CreateLogGroup",
        "logs:PutLogEvents"
      ],
      "Resource": "*"
    },
    {
      "Sid": "schedule",
      "Effect": "Allow",
      "Action": [
        "ec2:StartInstances",
        "ec2:CreateTags",
        "ec2:StopInstances",
        "kms:CreateGrant"
      ],
      "Resource": "*"
    },
    {
      "Sid": "describe",
      "Effect": "Allow",
      "Action": [
        "ec2:DescribeInstances"
      ],
      "Resource": "*"
    }
  ]
}

```

Note this example policy is not restricted to any particular logs or
instances. It is recommended to limit permissions to logs and instances the
function is allowed to affect. Consider pre-creating log groups rather than
allowing the lambda to. The DescribeInstances permission must be given to *.